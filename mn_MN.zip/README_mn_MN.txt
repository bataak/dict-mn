Туршилтын хувилбар болох ойролцоогоор 2 сая үгийн сантай толио гаргаснаас хойш
даруй 13 жил өнгөрчээ. Энэ удаагийн шинэчлэлээр 40 мянга орчим, тэдгээрийн
хувилал болох 400 сая гаруй үгийн санг бэлтгэлээ.

Энэхүү толийн онцлог гэвэл эрдэмтэн Ц. Дамдинсүрэн нарын 'Монгол үсгийн дүрмийн
толь', 'Монгол хэлний хадмал толь', 'Монгол хэлний их тайлбар толь' болон
'Монгол хэлний зөв бичих дүрмийн журамласан толь' зэрэг бүтээлүүдийг тусгасан
болно.

Өөрчлөн тараахыг хориглоно. Зохиогчийн эрх хуулиар хамгаалагдсан.

Уг толийг хэрэглээний программууд дээр хэрхэн ашиглах талаарх зааварчилгыг
  https://zuv.bichig.dev
цахим хуудаснаас авна уу!

---

Copyright 2020-present, Batmunkh Dorjgotov <bataak at gmail tseg com>

Special thanks to Guntevsuren Nanzad for your great professional assistance.

This work may be distributed and/or modified under the
conditions of the LaTeX Project Public License, either version 1.3
of this license or (at your option) any later version.
The latest version of this license is in
  http://www.latex-project.org/lppl.txt
and version 1.3 or later is part of all distributions of LaTeX
version 2005/12/01 or later.

This work has the LPPL maintenance status maintained.

The Current Maintainer of this work is Batmunkh Dorjgotov.

This work consists of the files mn_MN.aff, mn_MN.dic, mn_MN.zip and
README_mn_MN.txt.
