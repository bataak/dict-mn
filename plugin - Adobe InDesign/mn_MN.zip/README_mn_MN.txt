Туршилтын хувилбар болох ойролцоогоор 2 сая үгийн сантай толио гаргаснаас хойш даруй 12 жил өнгөрчээ. Энэ удаагийн шинэчлэлээр 36 мянга орчим, тэдгээрийн хувилал болох 200 сая гаруй үгийн санг бэлтгэлээ.

Энэхүү толийн онцлог гэвэл эрдэмтэн Ц. Дамдинсүрэн нарын `Монгол үсгийн дүрмийн толь', `Монгол хэлний хадмал толь', `Монгол хэлний их тайлбар толь' болон `Монгол хэлний зөв бичих дүрмийн журамласан толь' зэрэг бүтээлүүдийг тусгасан болно.

Өөрчлөн тараахыг хориглоно. Зохиогчийн эрх хуулиар хамгаалагдсан.

---

Copyright 2020-present, Batmunkh Dorjgotov <bataak at gmail tseg com>

This work may be distributed and/or modified under the
conditions of the LaTeX Project Public License, either version 1.3
of this license or (at your option) any later version.
The latest version of this license is in
  http://www.latex-project.org/lppl.txt
and version 1.3 or later is part of all distributions of LaTeX
version 2005/12/01 or later.

This work has the LPPL maintenance status maintained.

The Current Maintainer of this work is Batmunkh Dorjgotov.

This work consists of the files mn_MN.aff, mn_MN.dic and README_mn_MN.txt
and the derived file hyph_mn_MN.dic from mnhyphn.tex.
